package javax.persistence;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @since 2017-05-22
 * @version 1.0
 * @author marcos morise
 */
public abstract class EntityManager {

//*****************************************************************************
// Auxiliar Commands **********************************************************
//*****************************************************************************
    /**
     * Return Table Definition based in Class name or tableDefinition anotation
     *
     * @param entityType
     * @return Table Definition
     */
    protected static String getTableDefinition(Class entityType) {
        String tableDefinition = "";
        if (entityType.isAnnotationPresent(Entity.class)) {
            tableDefinition = ((Entity) entityType.getAnnotation(Entity.class)).tableDefinition();
        }
        if (tableDefinition.isEmpty()) {
            tableDefinition = entityType.getSimpleName();
        }
        return tableDefinition;
    } //getTableDefinition

    /**
     * Return Column Definition based in field name or columnDefinition
     * anotation
     *
     * @param field
     * @return Table Column Definition
     */
    protected static String getColumnDefinition(Field field) {
        String columnDefinition = "";
        if (field.isAnnotationPresent(Column.class)) {
            columnDefinition = field.getAnnotation(Column.class).columnDefinition();
        } else if (field.isAnnotationPresent(GeneratedValue.class)) {
            columnDefinition = field.getAnnotation(GeneratedValue.class).columnDefinition();
        } else if (field.isAnnotationPresent(Temporal.class)) {
            columnDefinition = field.getAnnotation(Temporal.class).columnDefinition();
        } else if (field.isAnnotationPresent(Lob.class)) {
            columnDefinition = field.getAnnotation(Lob.class).columnDefinition();
        } else if (field.isAnnotationPresent(ManyToOne.class)) {
            columnDefinition = field.getAnnotation(ManyToOne.class).columnDefinition();
        } else if (field.isAnnotationPresent(Enumerated.class)) {
            columnDefinition = field.getAnnotation(Enumerated.class).columnDefinition();
        }
        if (columnDefinition.isEmpty()) {
            columnDefinition = field.getName();
        }
        return columnDefinition;
    } //getColumnDefinition

    /**
     * Verify if 2 entities values are equals
     *
     * @param entity1
     * @param entity2
     * @return true equals || false different
     * @throws java.sql.SQLException
     */
    protected static Boolean isEntitiesEquals(Object entity1, Object entity2) throws SQLException {
        Boolean equals = true;
        try {
            if (entity1.getClass() == entity2.getClass()) {
                Class entityType = entity1.getClass();
                for (int i = 0; i < entityType.getDeclaredFields().length; i++) {
                    Field field1 = entity1.getClass().getDeclaredFields()[i];
                    Method getter = getFieldGetter(entity1, field1);
                    if (field1.isAnnotationPresent(Column.class) || field1.getClass().isAnnotationPresent(GeneratedValue.class)) {
                        String value1 = getter.invoke(entity1).toString().trim();
                        String value2 = getter.invoke(entity2).toString().trim();
                        equals = value1.equals(value2);
                    } else if (field1.isAnnotationPresent(Temporal.class)) {
                        Date value1 = (Date) getter.invoke(entity1);
                        Date value2 = (Date) getter.invoke(entity2);
                        equals = value1.equals(value2);
                    } else if (field1.isAnnotationPresent(Enumerated.class)) {
                        Enum value1 = (Enum) getter.invoke(entity1);
                        Enum value2 = (Enum) getter.invoke(entity2);
                        equals = value1.equals(value2);
                    } else if (field1.isAnnotationPresent(Lob.class)) {
                        byte[] value1 = (byte[]) getter.invoke(entity1);
                        byte[] value2 = (byte[]) getter.invoke(entity2);
                        equals = java.util.Arrays.equals(value1, value2);
                    } else if (field1.isAnnotationPresent(ManyToOne.class)) {
                        Object value1 = getter.invoke(entity1);
                        Object value2 = getter.invoke(entity2);
                        equals = isEntitiesEquals(value1, value2);
                    } else if (field1.isAnnotationPresent(OneToMany.class)) {
                        List<Object> value1 = (List<Object>) getter.invoke(entity1);
                        List<Object> value2 = (List<Object>) getter.invoke(entity2);
                        if (value1.size() != value2.size()) {
                            equals = false;
                        } else {
                            for (int j = 0; j < value1.size(); j++) {
                                Object value1Id = getFieldGetter(value1.get(j), getEntityId(value1.get(j))).invoke(value1.get(j));
                                Object value2Id = getFieldGetter(value2.get(j), getEntityId(value2.get(j))).invoke(value2.get(j));
                                if (value1Id.equals(value2Id) && !isEntitiesEquals(value1.get(j), value2.get(j))) {
                                    equals = false;
                                    j = value1.size();
                                }
                            }
                        }
                    }
                    if (!equals) {
                        i = entityType.getDeclaredFields().length;
                    }
                }
            } else {
                equals = false;
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NullPointerException ex) {
            throw new SQLException(ex);
        }
        return equals;
    } //isEntitiesEquals

    /**
     * get id field from class
     *
     * @param entityType
     * @return id field
     */
    protected static Field getClassId(Class entityType) {
        Field fieldId = null;
        for (Field field : entityType.getDeclaredFields()) {
            if (field.isAnnotationPresent(Id.class) && (field.getType() == Integer.class || field.getType() == Long.class || field.getType() == String.class)) {
                fieldId = field;
            }
        }
        return fieldId;
    } //getClassId

    /**
     * get id field from entity
     *
     * @param entity
     * @return id field
     */
    protected static Field getEntityId(Object entity) {
        Field fieldId = null;
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(Id.class) && (field.getType() == Integer.class || field.getType() == Long.class || field.getType() == String.class)) {
                fieldId = field;
            }
        }
        return fieldId;
    } //getEntityId

    /**
     * get Field method Getter
     *
     * @param entity
     * @param field
     * @return method getter
     */
    protected static Method getFieldGetter(Object entity, Field field) {
        Method getter;
        String fieldName = field.getName().substring(0, 1).toUpperCase() + (field.getName().length() > 1 ? field.getName().substring(1) : "");
        try {
            getter = entity.getClass().getMethod("get" + fieldName);
        } catch (NoSuchMethodException | SecurityException ex) {
            getter = null;
        }
        return getter;
    } //getFieldGetter

    /**
     * get Field method Setter
     *
     * @param entity
     * @param field
     * @return method setter
     */
    protected static Method getFieldSetter(Object entity, Field field) {
        Method setter;
        String fieldName = field.getName().substring(0, 1).toUpperCase() + (field.getName().length() > 1 ? field.getName().substring(1) : "");
        try {
            setter = entity.getClass().getMethod("set" + fieldName, field.getType());
        } catch (NoSuchMethodException | SecurityException ex) {
            setter = null;
        }
        return setter;
    } //getFieldSetter

//*****************************************************************************
// SQL Update Commands ********************************************************
//*****************************************************************************

//*****************************************************************************
// CREATE TABLE Commands ******************************************************
//*****************************************************************************
    /**
     * Create Table SQL Command
     *
     * @param owner
     * @param ownerField
     * @param child
     * @return
     */
    protected static String createTableSQL(Class owner, Field ownerField, Class child) {
        String sql = "";
        String primaryKey = "";
        String foreignKeys = "";
        String tableDefinition = getTableDefinition(child);
        sql += "CREATE TABLE " + tableDefinition + " (\n";

        //if is child, add OneToMany owner column
        if (owner != null && ownerField != null) {
            //set name column
            String fieldName;
            if (ownerField.getAnnotation(OneToMany.class).joinColumn().isEmpty()) {
                fieldName = owner.getSimpleName() + "_" + getClassId(owner).getName();
            } else {
                fieldName = ownerField.getAnnotation(OneToMany.class).joinColumn();
            }
            //set type column
            Field classOwnerId = getClassId(owner);
            if (classOwnerId.getType() == Integer.class) {
                sql += "    " + fieldName + " INT NOT NULL,\n";
            } else if (classOwnerId.getType() == Long.class) {
                sql += "    " + fieldName + " BIGINT NOT NULL,\n";
            } else {
                if (classOwnerId.getAnnotation(Column.class).length() > 0) {
                    sql += "    " + fieldName + " VARCHAR(" + classOwnerId.getAnnotation(Column.class).length() + ") NOT NULL,\n";
                } else {
                    sql += "    " + fieldName + " LONG VARCHAR NOT NULL,\n";
                }
            }
            foreignKeys += "    CONSTRAINT FKA_" + tableDefinition + "_" + getTableDefinition(owner) + " FOREIGN KEY (" + fieldName + ") REFERENCES " + getTableDefinition(owner) + " ON DELETE CASCADE,\n";
        }//add OneToMany owner column

        //add other columns
        for (Field field : child.getDeclaredFields()) {
            String fieldName = getColumnDefinition(field);
            if (field.isAnnotationPresent(Id.class)) {
                primaryKey = "    CONSTRAINT PK_" + tableDefinition + " PRIMARY KEY (" + fieldName + "),\n";
            }
            //Generated Value
            if (field.isAnnotationPresent(GeneratedValue.class)) {
                if (field.getType() == Integer.class) {
                    sql += "    " + fieldName + " INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH " + field.getAnnotation(GeneratedValue.class).startWith() + ", INCREMENT BY " + field.getAnnotation(GeneratedValue.class).incrementBy() + "),\n";
                } else if (field.getType() == Long.class) {
                    sql += "    " + fieldName + " BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH " + field.getAnnotation(GeneratedValue.class).startWith() + ", INCREMENT BY " + field.getAnnotation(GeneratedValue.class).incrementBy() + "),\n";
                }
            } else if (field.isAnnotationPresent(Enumerated.class)) {
                //Enumerated Type
                if (field.getType().getSuperclass() == Enum.class) {
                    sql += "    " + fieldName + " INT NOT NULL,\n";
                }
            } else if (field.isAnnotationPresent(Temporal.class)) {
                //Temporal Type
                if (field.getType() == Date.class) {
                    if (field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                        sql += "    " + fieldName + " DATE NOT NULL,\n";
                    } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                        sql += "    " + fieldName + " TIME NOT NULL,\n";
                    } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                        sql += "    " + fieldName + " TIMESTAMP NOT NULL,\n";
                    }
                }
            } else if (field.isAnnotationPresent(Lob.class)) {
                //Lob Type
                if (field.getType() == byte[].class) {
                    sql += "    " + fieldName + " BLOB NOT NULL,\n";
                }
            } else if (field.isAnnotationPresent(ManyToOne.class)) {
                //ManyToOne Type
                Class joinClass = field.getType();
                Field joinClassId = null;
                for (Field joinClassField : joinClass.getDeclaredFields()) {
                    if (joinClassField.isAnnotationPresent(Id.class)) {
                        joinClassId = joinClassField;
                    }
                }
                if (joinClassId != null) {
                    if (joinClassId.getType() == String.class) {
                        if (joinClassId.getAnnotation(Column.class).length() > 0) {
                            sql += "    " + fieldName + " VARCHAR(" + joinClassId.getAnnotation(Column.class).length() + ") NOT NULL,\n";
                        } else {
                            sql += "    " + fieldName + " LONG VARCHAR NOT NULL,\n";
                        }
                    } else if (joinClassId.getType() == Integer.class) {
                        sql += "    " + fieldName + " INT NOT NULL,\n";
                    } else {
                        sql += "    " + fieldName + " BIGINT NOT NULL,\n";
                    }
                }
                foreignKeys += "    CONSTRAINT FKA_" + tableDefinition + "_" + fieldName + " FOREIGN KEY (" + fieldName + ") REFERENCES " + getTableDefinition(field.getType()) + " ON DELETE CASCADE,\n";
            } else if (field.isAnnotationPresent(Column.class)) {
                //Column Type
                if (field.getType() == Boolean.class) {
                    sql += "    " + fieldName + " BOOLEAN" + (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "") + ",\n";
                } else if ((field.getType() == Byte.class || field.getType() == Short.class) && field.isAnnotationPresent(Column.class)) {
                    sql += "    " + fieldName + " SMALLINT" + (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "") + ",\n";
                } else if (field.getType() == Integer.class) {
                    sql += "    " + fieldName + " INT" + (field.getAnnotation(Column.class).unique() && !field.isAnnotationPresent(Id.class) ? " UNIQUE NOT NULL" : (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "")) + ",\n";
                } else if (field.getType() == Long.class) {
                    sql += "    " + fieldName + " BIGINT" + (field.getAnnotation(Column.class).unique() && !field.isAnnotationPresent(Id.class) ? " UNIQUE NOT NULL" : (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "")) + ",\n";
                } else if (field.getType() == Float.class) {
                    sql += "    " + fieldName + " FLOAT" + (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "") + ",\n";
                } else if (field.getType() == Double.class) {
                    sql += "    " + fieldName + " DOUBLE" + (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "") + ",\n";
                } else if (field.getType() == Character.class) {
                    sql += "    " + fieldName + " CHAR" + (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "") + ",\n";
                } else if (field.getType() == String.class) {
                    if (field.getAnnotation(Column.class).length() > 0) {
                        sql += "    " + fieldName + " VARCHAR(" + field.getAnnotation(Column.class).length() + ")" + (field.getAnnotation(Column.class).unique() && !field.isAnnotationPresent(Id.class) ? " UNIQUE NOT NULL" : (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "")) + ",\n";
                    } else {
                        sql += "    " + fieldName + " LONG VARCHAR" + (field.getAnnotation(Column.class).unique() ? " UNIQUE NOT NULL" : (!field.getAnnotation(Column.class).nullable() ? " NOT NULL" : "")) + ",\n";
                    }
                }
            }
        } //add other columns
        //endding sql
        sql += primaryKey + foreignKeys;
        sql = sql.substring(0, sql.length() - 2) + "\n";
        sql += ")";

        return sql;
    }//createTableSQL

    /**
     * CreateTable used to create Tables child from entity OneToMany with SQL
     * cmd pre-defined Used to Modify API to support other Databases
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param child
     * @param sql
     * @throws SQLException
     */
    protected static void createTableExecute(Connection connection, Class owner, Field ownerField, Class child, String sql) throws SQLException {
        if (child.isAnnotationPresent(Entity.class)) {
            //String sql = createTableSQL(owner, ownerField, child);
            //Execute Create Table SQL command
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.executeUpdate();
            statement.close();

            //Create OneToMany table childs
            for (Field field : child.getDeclaredFields()) {
                if (field.isAnnotationPresent(OneToMany.class)) {
                    createTable(connection, child, field, (Class<?>) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0]);
                }
            }
        }
    }//createTableExecute

    /**
     * CreateTable used to create Tables child from entity OneToMany
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param child
     * @throws SQLException
     */
    protected static void createTable(Connection connection, Class owner, Field ownerField, Class child) throws SQLException {
        if (child.isAnnotationPresent(Entity.class)) {
            String sql = createTableSQL(owner, ownerField, child);
            System.out.println("\n" + sql + "\n");
            createTableExecute(connection, owner, ownerField, child, sql);
        }
    }//createTable

    /**
     * Create database from entityType
     *
     * @param connection
     * @param entityType
     * @throws SQLException
     */
    public static void createTable(Connection connection, Class entityType) throws SQLException {
        createTable(connection, null, null, entityType);
    } //createTable

//*****************************************************************************
// INSERT Commands ************************************************************
//*****************************************************************************
    /**
     * insertExecute SQL command
     *
     * @param owner
     * @param ownerField
     * @param entity
     * @return SQL command [0] insertExecute , [i] select identity
     */
    protected static String[] insertSQL(Object owner, Field ownerField, Object entity) {
        String sql = "";
        String selectIdentity = "";
        String values = "";
        String tableDefinition = getTableDefinition(entity.getClass());

        //Create sql command
        sql += "INSERT INTO " + tableDefinition + " (";
        //Command parameters
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(GeneratedValue.class)
                    && (field.isAnnotationPresent(Column.class)// && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                    || field.isAnnotationPresent(Temporal.class)// && field.getType() == Date.class)
                    || field.isAnnotationPresent(Enumerated.class)// && field.getType().getSuperclass() == Enum.class)
                    || field.isAnnotationPresent(Lob.class)// && field.getType() == byte[].class)
                    || field.isAnnotationPresent(ManyToOne.class))) {
                sql += getColumnDefinition(field) + ",";
                values += "?,";
            }
            if (field.isAnnotationPresent(GeneratedValue.class)) {
                selectIdentity = "SELECT IDENTITY_VAL_LOCAL() FROM " + tableDefinition;
            }
        }
        //If is OneToMany child entity
        if (owner != null && ownerField != null) {
            if (!ownerField.getAnnotation(OneToMany.class).joinColumn().isEmpty()) {
                sql += ownerField.getAnnotation(OneToMany.class).joinColumn() + ",";
            } else {
                sql += owner.getClass().getSimpleName() + "_" + (getEntityId(owner).getName()) + ",";
            }
            values += "?,";
        }
        //Finalize sql command creation
        sql = sql.substring(0, sql.length() - 1);
        values = values.substring(0, values.length() - 1);
        sql += ")\nVALUES (" + values + ")";

        //Prepare to Insert Entity Into Database
        return new String[]{sql, selectIdentity};
    }//insertSQL

    /**
     * Protected Insert used to insert child from entity OneToMany with SQL cmd
     * pre-defined Used to Modify API to support other Databases
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param entity
     * @param sqlCmd
     * @throws SQLException
     */
    protected static void insertExecute(Connection connection, Object owner, Field ownerField, Object entity, String sqlCmd[]) throws SQLException {
        if (entity.getClass().isAnnotationPresent(Entity.class)) {
            try {
                String sql = sqlCmd[0];
                String selectIdentity = sqlCmd[1];
                PreparedStatement statement = connection.prepareStatement(sql);

                //Setting values for statement
                int i = 0;
                for (Field field : entity.getClass().getDeclaredFields()) {
                    try {
                        if (!field.isAnnotationPresent(GeneratedValue.class)
                                && (field.isAnnotationPresent(Column.class)// && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                                || field.isAnnotationPresent(Temporal.class)// && field.getType() == Date.class)
                                || field.isAnnotationPresent(Enumerated.class)// && field.getType().getSuperclass() == Enum.class)
                                || field.isAnnotationPresent(Lob.class)// && field.getType() == byte[].class)
                                || field.isAnnotationPresent(ManyToOne.class))) {
                            Method getter = getFieldGetter(entity, field);
                            i++;
                            if (field.getType() == Boolean.class) {
                                statement.setBoolean(i, (Boolean) getter.invoke(entity));
                            } else if (field.getType() == Byte.class) {
                                statement.setByte(i, (Byte) getter.invoke(entity));
                            } else if (field.getType() == Short.class) {
                                statement.setShort(i, (Short) getter.invoke(entity));
                            } else if (field.getType() == Integer.class) {
                                statement.setInt(i, (Integer) getter.invoke(entity));
                            } else if (field.getType() == Long.class) {
                                statement.setLong(i, (Long) getter.invoke(entity));
                            } else if (field.getType() == Float.class) {
                                statement.setFloat(i, (Float) getter.invoke(entity));
                            } else if (field.getType() == Double.class) {
                                statement.setDouble(i, (Double) getter.invoke(entity));
                            } else if (field.getType() == Character.class) {
                                statement.setString(i, "" + (Character) getter.invoke(entity));
                            } else if (field.getType() == String.class) {
                                statement.setString(i, (String) getter.invoke(entity));
                            } else if (field.getType().getSuperclass() == Enum.class) {
                                statement.setInt(i, ((Enum) getter.invoke(entity)).ordinal());
                            } else if (field.getType() == byte[].class) {
                                statement.setBlob(i, new java.io.ByteArrayInputStream((byte[]) getter.invoke(entity)));
                            } else if (field.getType() == Date.class) {
                                if (field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                                    statement.setTime(i, new java.sql.Time(((Date) getter.invoke(entity)).getTime()));
                                } else if (field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                                    statement.setDate(i, new java.sql.Date(((Date) getter.invoke(entity)).getTime()));
                                } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                                    statement.setTimestamp(i, java.sql.Timestamp.from(((Date) getter.invoke(entity)).toInstant()));
                                }
                            } else if (field.isAnnotationPresent(ManyToOne.class)) {
                                Object agregateObj = getter.invoke(entity);
                                Field agregateObjId = getEntityId(agregateObj);
                                Method getterId = getFieldGetter(agregateObj, agregateObjId);
                                if (agregateObjId.getType() == Integer.class) {
                                    statement.setInt(i, (Integer) getterId.invoke(agregateObj));
                                } else if (agregateObjId.getType() == Long.class) {
                                    statement.setLong(i, (Long) getterId.invoke(agregateObj));
                                } else if (agregateObjId.getType() == String.class) {
                                    statement.setString(i, (String) getterId.invoke(agregateObj));
                                }
                            }
                        }
                    } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NullPointerException ex) {
                        //ex.printStackTrace();
                        throw new SQLException(ex.getMessage());
                    }
                }

                //If is OneToMany child entity
                if (owner != null && ownerField != null) {
                    i++;
                    Field ownerId = getEntityId(owner);
                    Method getterOwnerId = getFieldGetter(owner, ownerId);
                    //Define owner parameter
                    if (ownerId.getType() == Integer.class) {
                        statement.setInt(i, (Integer) getterOwnerId.invoke(owner));
                    } else if (ownerId.getType() == Long.class) {
                        statement.setLong(i, (Long) getterOwnerId.invoke(owner));
                    } else if (ownerId.getType() == String.class) {
                        statement.setString(i, (String) getterOwnerId.invoke(owner));
                    }
                }

                //Insert Entity Into Database
                statement.executeUpdate();
                statement.close();

                //set Generated Value to Field
                if (!selectIdentity.isEmpty()) {
                    statement = connection.prepareStatement(selectIdentity);
                    ResultSet rs = statement.executeQuery();
                    if (rs.next()) {
                        Field fId = getEntityId(entity);
                        Method setterId = getFieldSetter(entity, fId);
                        if (fId.getType() == Integer.class) {
                            setterId.invoke(entity, rs.getInt(1));
                        } else if (fId.getType() == Long.class) {
                            setterId.invoke(entity, rs.getLong(1));
                        }
                    }
                    statement.close();
                }

                //Insert OneToMany childs
                for (Field field : entity.getClass().getDeclaredFields()) {
                    if (field.isAnnotationPresent(OneToMany.class)) {
                        List listChild = (List) getFieldGetter(entity, field).invoke(entity);
                        for (Object entityChild : listChild) {
                            insert(connection, entity, field, entityChild);
                        }
                    }
                }

            } catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException | NullPointerException ex) {
                //ex.printStackTrace();
                throw new SQLException(ex);
            }

        }
    } //insertExecute

    /**
     * Protected Insert used to insertExecute child from entity OneToMany
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param entity
     * @throws SQLException
     */
    protected static void insert(Connection connection, Object owner, Field ownerField, Object entity) throws SQLException {
        String sqlCmd[] = insertSQL(owner, ownerField, entity);
        System.out.println("\n" + sqlCmd[0] + "\n" + sqlCmd[1] + "\n");
        insertExecute(connection, owner, ownerField, entity, sqlCmd);
    }

    /**
     * Insert Entity Into Database
     *
     * @param connection
     * @param entity
     * @throws SQLException
     */
    public static void insert(Connection connection, Object entity) throws SQLException {
        insert(connection, null, null, entity);
    } //insert

//*****************************************************************************
// UPDATE Commands ************************************************************
//*****************************************************************************
    /**
     * Update SQL command
     *
     * @param connection
     * @param entity
     * @return SQL command
     * @throws SQLException
     */
    protected static String updateSQL(Connection connection, Object entity) throws SQLException {
        String sql = "";
        String tableDefinition = getTableDefinition(entity.getClass());
        Field entityId = getEntityId(entity);

        //Update command
        //Create sql command
        sql += "UPDATE " + tableDefinition + " SET ";
        //command parameters
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(GeneratedValue.class) && !field.isAnnotationPresent(Id.class)
                    && (field.isAnnotationPresent(Column.class)// && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                    || field.isAnnotationPresent(Temporal.class)// && field.getType() == Date.class)
                    || field.isAnnotationPresent(Enumerated.class)// && field.getType().getSuperclass() == Enum.class)
                    || field.isAnnotationPresent(Lob.class)// && field.getType() == byte[].class)
                    || field.isAnnotationPresent(ManyToOne.class))) {
                sql += "\n" + getColumnDefinition(field) + " = ?,";
            }
        }

        //Finalize sql command creation
        sql = sql.substring(0, sql.length() - 1);
        sql += "\nWHERE " + getColumnDefinition(entityId) + " = ?";

        return sql;
    } //updateSQL

    /**
     * Protected Update used to set SQL command pre-defined Used to Modify API
     * to support other Databases
     *
     * @param connection
     * @param entity
     * @param sql
     * @throws SQLException
     */
    protected static void updateExecute(Connection connection, Object entity, String sql) throws SQLException {
        if (entity.getClass().isAnnotationPresent(Entity.class)) {
            try {
                Field entityId = getEntityId(entity);
                Method getterId = getFieldGetter(entity, entityId);
                Object entityStored;
                if (entityId.getType() == String.class || entityId.getType() == Character.class) {
                    entityStored = load(connection, entity.getClass(), entityId.getName() + " = '" + getterId.invoke(entity)+"'");
                } else {
                    entityStored = load(connection, entity.getClass(), entityId.getName() + " = " + getterId.invoke(entity));
                }

                if (!isEntitiesEquals(entity, entityStored)) {
                    //Prepare to Update Entity from Database
                    PreparedStatement statement = connection.prepareStatement(sql);

                    //Setting values for statement
                    int i = 0;
                    for (Field field : entity.getClass().getDeclaredFields()) {
                        try {
                            if (!field.isAnnotationPresent(GeneratedValue.class) && !field.isAnnotationPresent(Id.class)
                                    && (field.isAnnotationPresent(Column.class)// && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                                    || field.isAnnotationPresent(Temporal.class)// && field.getType() == Date.class)
                                    || field.isAnnotationPresent(Enumerated.class)// && field.getType().getSuperclass() == Enum.class)
                                    || field.isAnnotationPresent(Lob.class)// && field.getType() == byte[].class)
                                    || field.isAnnotationPresent(ManyToOne.class))) {
                                Method getter = getFieldGetter(entity, field);
                                i++;
                                if (field.getType() == Boolean.class) {
                                    statement.setBoolean(i, (Boolean) getter.invoke(entity));
                                } else if (field.getType() == Byte.class) {
                                    statement.setByte(i, (Byte) getter.invoke(entity));
                                } else if (field.getType() == Short.class) {
                                    statement.setShort(i, (Short) getter.invoke(entity));
                                } else if (field.getType() == Integer.class) {
                                    statement.setInt(i, (Integer) getter.invoke(entity));
                                } else if (field.getType() == Long.class) {
                                    statement.setLong(i, (Long) getter.invoke(entity));
                                } else if (field.getType() == Float.class) {
                                    statement.setFloat(i, (Float) getter.invoke(entity));
                                } else if (field.getType() == Double.class) {
                                    statement.setDouble(i, (Double) getter.invoke(entity));
                                } else if (field.getType() == Character.class) {
                                    statement.setString(i, "" + (Character) getter.invoke(entity));
                                } else if (field.getType() == String.class) {
                                    statement.setString(i, (String) getter.invoke(entity));
                                } else if (field.getType().getSuperclass() == Enum.class) {
                                    statement.setInt(i, ((Enum) getter.invoke(entity)).ordinal());
                                } else if (field.getType() == byte[].class) {
                                    statement.setBlob(i, new java.io.ByteArrayInputStream((byte[]) getter.invoke(entity)));
                                } else if (field.getType() == Date.class) {
                                    if (field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                                        statement.setTime(i, new java.sql.Time(((Date) getter.invoke(entity)).getTime()));
                                    } else if (field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                                        statement.setDate(i, new java.sql.Date(((Date) getter.invoke(entity)).getTime()));
                                    } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                                        statement.setTimestamp(i, java.sql.Timestamp.from(((Date) getter.invoke(entity)).toInstant()));
                                    }
                                } else if (field.isAnnotationPresent(ManyToOne.class)) {
                                    Object agregateObj = getter.invoke(entity);
                                    Field agregateObjId = getEntityId(agregateObj);
                                    Method getterIdAgr = getFieldGetter(agregateObj, agregateObjId);
                                    if (agregateObjId.getType() == Integer.class) {
                                        statement.setInt(i, (Integer) getterIdAgr.invoke(agregateObj));
                                    } else if (agregateObjId.getType() == Long.class) {
                                        statement.setLong(i, (Long) getterIdAgr.invoke(agregateObj));
                                    } else if (agregateObjId.getType() == String.class) {
                                        statement.setString(i, (String) getterIdAgr.invoke(agregateObj));
                                    }
                                }
                            }
                        } catch (SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NullPointerException ex) {
                            //ex.printStackTrace();
                            throw new SQLException(ex.getMessage());
                        }
                    }

                    i++;
                    if (entityId.getType() == Integer.class) {
                        statement.setInt(i, (Integer) getterId.invoke(entity));
                    } else if (entityId.getType() == Long.class) {
                        statement.setLong(i, (Long) getterId.invoke(entity));
                    } else if (entityId.getType() == String.class) {
                        statement.setString(i, (String) getterId.invoke(entity));
                    }

                    //Update Entity into Database
                    statement.executeUpdate();
                    statement.close();

                    //Verify childs One to Many
                    for (Field field : entity.getClass().getDeclaredFields()) {
                        if (field.isAnnotationPresent(OneToMany.class)) {
                            List listChild = (List) getFieldGetter(entity, field).invoke(entity);
                            List listChildStored = (List) getFieldGetter(entityStored, field).invoke(entityStored);

                            //Verify removed or changed stored OneToMany childs to deleteExecute or updateExecute on cascade
                            for (Object entityChildStored : listChildStored) {
                                Boolean exists = false;
                                for (Object entityChild : listChild) {
                                    Method getterChildStoredId = getFieldGetter(entityChildStored, getEntityId(entityChildStored));
                                    Method getterChildId = getFieldGetter(entityChild, getEntityId(entityChild));
                                    Object valueStoredId = getterChildStoredId.invoke(entityChildStored);
                                    Object valueId = getterChildId.invoke(entityChild);
                                    if (valueId != null && valueId.equals(valueStoredId)) {
                                        exists = true;
                                        if (!isEntitiesEquals(entityChild, entityChildStored)) {
                                            update(connection, entityChild);
                                        }
                                    }
                                }
                                if (!exists) {
                                    delete(connection, entityChildStored);
                                }
                            }

                            //Verify new OneToMany childs to insertExecute on cascade
                            for (Object entityChild : listChild) {
                                Boolean exists = false;
                                for (Object entityChildStored : listChildStored) {
                                    Method getterChildStoredId = getFieldGetter(entityChildStored, getEntityId(entityChildStored));
                                    Method getterChildId = getFieldGetter(entityChild, getEntityId(entityChild));
                                    Object valueStoredId = getterChildStoredId.invoke(entityChildStored);
                                    Object valueId = getterChildId.invoke(entityChild);
                                    if (valueId != null && valueId.equals(valueStoredId)) {
                                        exists = true;
                                    }
                                }
                                if (!exists) {
                                    insert(connection, entity, field, entityChild);
                                }
                            }
                        }

                    }
                }

            } catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException | NullPointerException ex) {
                ex.printStackTrace();
                throw new SQLException(ex);
            }

        }
    } //updateExecute

    /**
     * Update Entity from Database
     *
     * @param connection
     * @param entity
     * @throws SQLException
     */
    public static void update(Connection connection, Object entity) throws SQLException {
        String sql = updateSQL(connection, entity);
        System.out.println("\n" + sql + "\n");
        updateExecute(connection, entity, sql);
    } //update

//*****************************************************************************
// DELETE Commands ************************************************************
//*****************************************************************************
    /**
     * Delete SQL command
     *
     * @param connection
     * @param entity
     * @return SQL command
     * @throws SQLException
     */
    protected static String deleteSQL(Connection connection, Object entity) throws SQLException {
        String tableDefinition = getTableDefinition(entity.getClass());
        Field entityId = getEntityId(entity);
        String sql = "DELETE FROM " + tableDefinition + " WHERE " + getColumnDefinition(entityId) + " = ?";
        return sql;
    } //deleteSQL

    /**
     * Protected Delete used to set SQL command pre-defined Used to Modify API
     * to support other Databases
     *
     * @param connection
     * @param entity
     * @param sql
     * @throws SQLException
     */
    protected static void deleteExecute(Connection connection, Object entity, String sql) throws SQLException {
        if (entity.getClass().isAnnotationPresent(Entity.class)) {
            try {
                Field entityId = getEntityId(entity);
                Method getter = getFieldGetter(entity, entityId);

                //Prepare to Delete Entity Into Database
                PreparedStatement statement = connection.prepareStatement(sql);

                if (entityId.getType() == Integer.class) {
                    statement.setInt(1, (Integer) getter.invoke(entity));
                } else if (entityId.getType() == Long.class) {
                    statement.setLong(1, (Long) getter.invoke(entity));
                } else if (entityId.getType() == String.class) {
                    statement.setString(1, (String) getter.invoke(entity));
                }

                //Delete Entity Database
                statement.executeUpdate();
                statement.close();
            } catch (IllegalArgumentException | IllegalAccessException | InvocationTargetException | NullPointerException ex) {
                //ex.printStackTrace();
                throw new SQLException(ex);
            }

        }
    } //deleteExecute

    /**
     * Delete Entity From Database
     *
     * @param connection
     * @param entity
     * @throws SQLException
     */
    public static void delete(Connection connection, Object entity) throws SQLException {
        String sql = deleteSQL(connection, entity);
        System.out.println("\n" + sql + "\n");
        deleteExecute(connection, entity, sql);
    } //delete

//*****************************************************************************
// SQL Query Commands ********************************************************
//*****************************************************************************
    /**
     * SQL Resultset to Entity
     *
     * @param connection
     * @param resultSet
     * @param entity
     * @throws SQLException
     */
    protected static void resultSetToEntity(Connection connection, ResultSet resultSet, Object entity) throws SQLException {
        try {
            Class entityType = entity.getClass();
            // Column | Id | Enumerated | Temporal | Lob Type
            for (Field field : entityType.getDeclaredFields()) {
                Method setter = getFieldSetter(entity, field);

                if (field.isAnnotationPresent(Column.class) || field.isAnnotationPresent(GeneratedValue.class) || field.isAnnotationPresent(Enumerated.class) || field.isAnnotationPresent(Temporal.class) || field.isAnnotationPresent(Lob.class)) {
                    if (field.getType() == Boolean.class) {
                        setter.invoke(entity, resultSet.getBoolean(getColumnDefinition(field)));
                    } else if (field.getType() == Byte.class) {
                        setter.invoke(entity, resultSet.getByte(getColumnDefinition(field)));
                    } else if (field.getType() == Short.class) {
                        setter.invoke(entity, resultSet.getShort(getColumnDefinition(field)));
                    } else if (field.getType() == Integer.class) {
                        setter.invoke(entity, resultSet.getInt(getColumnDefinition(field)));
                    } else if (field.getType() == Long.class) {
                        setter.invoke(entity, resultSet.getLong(getColumnDefinition(field)));
                    } else if (field.getType() == Float.class) {
                        setter.invoke(entity, resultSet.getFloat(getColumnDefinition(field)));
                    } else if (field.getType() == Double.class) {
                        setter.invoke(entity, resultSet.getDouble(getColumnDefinition(field)));
                    } else if (field.getType() == Character.class) {
                        setter.invoke(entity, resultSet.getString(getColumnDefinition(field)).charAt(0));
                    } else if (field.getType() == String.class) {
                        setter.invoke(entity, resultSet.getString(getColumnDefinition(field)));
                    } else if (field.getType().getSuperclass() == Enum.class) {
                        setter.invoke(entity, field.getType().getEnumConstants()[resultSet.getInt(getColumnDefinition(field))]);
                    } else if (field.getType() == Date.class) {
                        if (field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                            setter.invoke(entity, resultSet.getDate(getColumnDefinition(field)));
                        } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                            setter.invoke(entity, (Date) resultSet.getTime(getColumnDefinition(field)));
                        } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                            setter.invoke(entity, (Date) resultSet.getTimestamp(getColumnDefinition(field)));
                        }

                    } else if (field.getType() == byte[].class) {
                        setter.invoke(entity, resultSet.getBytes(getColumnDefinition(field)));
                    }
                }
            } // Column | Id | Temporal | Enumerated | Lob Type 

            //ManyToOne | OneToMany
            for (Field field : entityType.getDeclaredFields()) {
                Method setter = getFieldSetter(entity, field);

                if (field.isAnnotationPresent(ManyToOne.class)) {
                    //ManyToOne
                    Field fieldId = getClassId(field.getType());
                    if (fieldId.getType() == Integer.class) {
                        setter.invoke(entity, load(connection, field.getType(), fieldId.getName() + "=" + resultSet.getInt(getColumnDefinition(field))));
                    } else if (fieldId.getType() == Long.class) {
                        setter.invoke(entity, load(connection, field.getType(), fieldId.getName() + "=" + resultSet.getLong(getColumnDefinition(field))));
                    } else if (fieldId.getType() == String.class) {
                        setter.invoke(entity, load(connection, field.getType(), fieldId.getName() + "='" + resultSet.getString(getColumnDefinition(field)) + "'"));
                    }
                } else if (field.isAnnotationPresent(OneToMany.class)) {
                    //OneToMany
                    String fieldName;
                    if (!field.getAnnotation(OneToMany.class).joinColumn().isEmpty()) {
                        fieldName = field.getAnnotation(OneToMany.class).joinColumn();
                    } else {
                        fieldName = entity.getClass().getSimpleName() + "_" + (getEntityId(entity).getName());
                    }
                    Field entityId = getEntityId(entity);
                    Class fieldType = (Class<?>) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
                    if (entityId.getType() == Integer.class) {
                        setter.invoke(entity, loadList(connection, fieldType, fieldName + "=" + getFieldGetter(entity, getEntityId(entity)).invoke((entity))));
                    } else if (entityId.getType() == Long.class) {
                        setter.invoke(entity, loadList(connection, fieldType, fieldName + "=" + getFieldGetter(entity, getEntityId(entity)).invoke((entity))));
                    } else if (entityId.getType() == String.class) {
                        setter.invoke(entity, loadList(connection, fieldType, fieldName + "='" + getFieldGetter(entity, getEntityId(entity)).invoke((entity)) + "'"));
                    }
                }
            }
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
            //ex.printStackTrace();
            throw new SQLException(ex);
        }
    } //resultSetToEntity

//*****************************************************************************
// LOAD Commands **************************************************************
//*****************************************************************************
    /**
     * Load Entity SQL Command
     *
     * @param connection
     * @param entityType
     * @return
     * @throws SQLException
     */
    protected static String loadSQL(Connection connection, Class entityType) throws SQLException {
        String sql = "";
        String tableDefinition = getTableDefinition(entityType);

        //Create sql command
        sql += "SELECT ";

        for (Field field : entityType.getDeclaredFields()) {
            if ((field.isAnnotationPresent(Column.class) && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                    || (field.isAnnotationPresent(GeneratedValue.class) && (field.getType() == Integer.class || field.getType() == Long.class))
                    || (field.isAnnotationPresent(Temporal.class) && field.getType() == Date.class)
                    || (field.isAnnotationPresent(Enumerated.class) && field.getType().getSuperclass() == Enum.class)
                    || (field.isAnnotationPresent(Lob.class) && field.getType() == byte[].class)
                    || field.isAnnotationPresent(ManyToOne.class)) {
                sql += getColumnDefinition(field) + ",";
            }
        }
        sql = sql.substring(0, sql.length() - 1) + "\n";
        sql += "FROM " + tableDefinition + "\n";
        return sql;
    } //loadSQL

    /**
     * Protected Load used to set SQL command pre-defined Used to Modify API to
     * support other Databases
     *
     * @param <T>
     * @param connection
     * @param entityType
     * @param sql
     * @return object loaded or null
     * @throws SQLException
     */
    protected static <T> T loadExecute(Connection connection, Class<T> entityType, String sql) throws SQLException {
        Object entity = null;

        if (entityType.isAnnotationPresent(Entity.class)) {
            //execute SQL
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            //Populate Entity
            if (resultSet.next()) {
                try {
                    entity = entityType.getConstructor().newInstance();
                    resultSetToEntity(connection, resultSet, entity);
                } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NullPointerException ex) {
                    //ex.printStackTrace();
                    throw new SQLException(ex);
                }
            }

        }
        return entityType.cast(entity);
    } //loadExecute

    /**
     * Load object
     *
     * @param <T>
     * @param connection
     * @param entityType
     * @param condition
     * @return object loaded or null
     * @throws SQLException
     */
    public static <T> T load(Connection connection, Class<T> entityType, String condition) throws SQLException {
        String sql = loadSQL(connection, entityType);
        sql += "WHERE " + condition;
        System.out.println("\n" + sql + "\n");
        return loadExecute(connection, entityType, sql);
    } //load

//*****************************************************************************
// LOAD LIST Commands *********************************************************
//*****************************************************************************
    /**
     * Protected Object List used to set SQL command pre-defined Used to Modify
     * API to support other Databases
     *
     * @param <T>
     * @param connection
     * @param entityType
     * @param sql
     * @return Object List
     * @throws SQLException
     */
    protected static <T> List<T> loadListExecute(Connection connection, Class<T> entityType, String sql) throws SQLException {
        //Class fieldType = (Class<?>) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
        List<T> entityList = new java.util.ArrayList<>();

        if (entityType.isAnnotationPresent(Entity.class)) {
            //execute SQL
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            //Populate Entity
            while (resultSet.next()) {
                try {
                    Object entity = entityType.getConstructor().newInstance();
                    resultSetToEntity(connection, resultSet, entity);
                    entityList.add(entityType.cast(entity));
                } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    //ex.printStackTrace();
                    throw new SQLException(ex);
                }
            }
        }
        return entityList;
    } //loadListExecute

    /**
     * Load Object List
     *
     * @param <T>
     * @param connection
     * @param entityType
     * @param condition
     * @return
     * @throws SQLException
     */
    public static <T> List<T> loadList(Connection connection, Class<T> entityType, String condition) throws SQLException {
        String sql = loadSQL(connection, entityType);
        sql += sql.isEmpty() ? "" : "WHERE " + condition;
        System.out.println("\n" + sql + "\n");
        return loadListExecute(connection, entityType, sql);
    } //loadList

//*****************************************************************************
// SELECT SQL Commands ********************************************************
//*****************************************************************************
    /**
     * Select from Database with formatted result
     *
     * @param connection
     * @param query SQL query
     * @param floatPattern "" - Float || "#,##0.###" "#,##0.00" - String
     * @param doublePattern "" - Double || "#,##0.###" "#,##0.000" - String
     * @param datePattern "" - Date || "dd/MM/yyyy" "yyyy-MM-dd" - String
     * @param timePattern "" - Date || "hh:mm" "hh:mm:ss" - String
     * @param imageType "" - byte[] || "base64" "BASE64" - String
     * @return query result
     * @throws SQLException
     */
    public static List select(Connection connection, String query, String floatPattern, String doublePattern, String datePattern, String timePattern, String imageType) throws SQLException {
        System.out.println("\n" + query + "\n");
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet rs = statement.executeQuery();
        List result = new ArrayList();
        while (rs.next()) {
            List line = new ArrayList();
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                switch (rs.getMetaData().getColumnType(i)) {
                    case java.sql.Types.BOOLEAN:
                    case java.sql.Types.BIT:
                        line.add(rs.getBoolean(i));
                        break;
                    case java.sql.Types.TINYINT:
                    case java.sql.Types.SMALLINT:
                        line.add(rs.getShort(i));
                        break;
                    case java.sql.Types.INTEGER:
                        line.add(rs.getInt(i));
                        break;
                    case java.sql.Types.BIGINT:
                        line.add(rs.getLong(i));
                        break;
                    case java.sql.Types.NUMERIC:
                    case java.sql.Types.DECIMAL:
                    case java.sql.Types.REAL:
                    case java.sql.Types.FLOAT:
                        if (floatPattern == null || floatPattern.isEmpty()) {
                            line.add(rs.getFloat(i));
                        } else {
                            line.add(new DecimalFormat(floatPattern).format(rs.getFloat(i)));
                        }
                        break;
                    case java.sql.Types.DOUBLE:
                        if (doublePattern == null || doublePattern.isEmpty()) {
                            line.add(rs.getDouble(i));
                        } else {
                            line.add(new DecimalFormat(doublePattern).format(rs.getDouble(i)));
                        }
                        break;
                    case java.sql.Types.DATE:
                        if (datePattern == null || datePattern.isEmpty()) {
                            line.add(new java.util.Date(rs.getDate(i).getTime()));
                        } else {
                            line.add(new java.text.SimpleDateFormat(datePattern).format(rs.getDate(i)));
                        }
                        break;
                    case java.sql.Types.TIME:
                        if (timePattern == null || timePattern.isEmpty()) {
                            line.add(new java.util.Date(rs.getTime(i).getTime()));
                        } else {
                            line.add(new java.text.SimpleDateFormat(timePattern).format(rs.getTime(i)));
                        }
                        break;
                    case java.sql.Types.TIMESTAMP:
                        line.add(new java.util.Date(rs.getTimestamp(i).getTime()));
                        break;
                    case java.sql.Types.BLOB:
                    case java.sql.Types.CLOB:
                        if (imageType == null || imageType.isEmpty()) {
                            line.add(rs.getBytes(i));
                        } else {
                            try {
                                java.awt.image.BufferedImage bf = javax.imageio.ImageIO.read(rs.getBlob(i).getBinaryStream());
                                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                                javax.imageio.ImageIO.write(bf, "PNG", output);
                                line.add("data:image/png;base64," + java.util.Base64.getEncoder().encodeToString(output.toByteArray()));
                            } catch (java.io.IOException | IllegalArgumentException | NullPointerException | java.sql.SQLException e) {
                                line.add("");
                            }
                        }
                        break;
                    default:
                        line.add(rs.getString(i));
                        break;
                }
            }
            if (line.size() == 1) {
                result.add(line.get(0));
            } else {
                result.add(line);
            }
        }
        statement.close();
        return result;
    } //select

    /**
     * Select from Database with native types result
     *
     * @param connection
     * @param query SQL query
     * @return query result
     * @throws SQLException
     */
    public static List select(Connection connection, String query) throws SQLException {
        return select(connection, query, "", "", "", "", "");
    } //select

//*****************************************************************************
// JSON Commands **************************************************************
//*****************************************************************************
    /**
     * Select from Database and convert toJSON
     *
     * @param connection
     * @param query
     * @return
     */
    public static String selectToJSON(Connection connection, String query) {
        return selectToJSON(connection, query, "", "", "yyyy-MM-dd", "HH:mm", "base64");
    } //selectToJSON

    /**
     * Select from Database and convert toJSON
     *
     * @param connection
     * @param query
     * @param floatPattern "" - Float || "#,##0.###" "#,##0.00" - String
     * @param doublePattern "" - Double || "#,##0.###" "#,##0.000" - String
     * @param datePattern "" - Date || "dd/MM/yyyy" "yyyy-MM-dd" - String
     * @param timePattern "" - Date || "hh:mm" "hh:mm:ss" - String
     * @param imageType "" - byte[] || "base64" "BASE64" - String
     * @return
     */
    public static String selectToJSON(Connection connection, String query, String floatPattern, String doublePattern, String datePattern, String timePattern, String imageType) {
        String json = "";
        try {
            json += "[";
            List result = select(connection, query, floatPattern, doublePattern, datePattern, timePattern, imageType);
            for (int i = 0; i < result.size(); i++) {
                if (result.get(i) instanceof ArrayList) {
                    List line = (List) result.get(i);
                    json += "    [";
                    for (int j = 0; j < line.size(); j++) {
                        Object o = line.get(j);
                        if (o.getClass() == String.class) {
                            json += "\"" + line.get(j) + "\",";
                        } else {
                            json += line.get(j) + ",";
                        }
                    }
                    json = json.length() > 1 ? json.substring(0, json.length() - 1) + "],\n" : "[],\n";
                } else {
                    Object o = result.get(i);
                    if (o.getClass() == String.class) {
                        json += "\"" + result.get(i) + "\",\n";
                    } else {
                        json += result.get(i) + ",\n";
                    }
                }
            }
            json = json.length() > 2 ? json.substring(0, json.length() - 2) + "]\n" : "[]\n";
        } catch (SQLException ex) {
            json = "[]\n";
        }
        return json;
    } //selectToJSON

    /**
     * Entity to JSON
     *
     * @param entity Entity to convert
     * @return String json
     */
    public static String toJSON(Object entity) {
        String json = "";
        try {
            json += "{\n";

            //Insert fields
            for (Field field : entity.getClass().getDeclaredFields()) {
                if ((field.isAnnotationPresent(Column.class) && (field.getType() == Boolean.class || field.getType() == Byte.class || field.getType() == Short.class || field.getType() == Integer.class || field.getType() == Long.class || field.getType() == Float.class || field.getType() == Double.class || field.getType() == Character.class || field.getType() == String.class))
                        || (field.isAnnotationPresent(Temporal.class) && field.getType() == Date.class)
                        || (field.isAnnotationPresent(Enumerated.class) && field.getType().getSuperclass() == Enum.class)
                        || (field.isAnnotationPresent(Lob.class) && field.getType() == byte[].class)
                        || field.isAnnotationPresent(ManyToOne.class) || field.isAnnotationPresent(OneToMany.class) || field.isAnnotationPresent(GeneratedValue.class)) {
                    json += "\"" + field.getName() + "\" : ";
                    if (field.getType() == Boolean.class
                            || field.getType() == Byte.class
                            || field.getType() == Short.class
                            || field.getType() == Integer.class
                            || field.getType() == Long.class
                            || field.getType() == Float.class
                            || field.getType() == Double.class) {
                        json += getFieldGetter(entity, field).invoke(entity);
                    } else if (field.getType() == Character.class
                            || field.getType() == String.class) {
                        json += "\"" + getFieldGetter(entity, field).invoke(entity) + "\"";
                    } else if (field.getType() == byte[].class) { //toBase64
                        byte[] blobField = (byte[]) getFieldGetter(entity, field).invoke(entity);
                        if (blobField != null && blobField.length > 0) {
                            java.awt.image.BufferedImage bf = javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(blobField));
                            java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                            javax.imageio.ImageIO.write(bf, "PNG", output);
                            String base64 = java.util.Base64.getEncoder().encodeToString(output.toByteArray());
                            json += "\"data:image/png;base64," + base64 + "\"";
                        } else {
                            json += "\"\"";
                        }
                    } else if (field.getType().getSuperclass() == Enum.class) {
                        json += ((Enum) getFieldGetter(entity, field).invoke(entity)).ordinal();
                    } else if (field.getType() == Date.class) {
                        if (field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                            json += "\"" + new SimpleDateFormat("hh:mm:ss").format(getFieldGetter(entity, field).invoke(entity)) + "\"";
                        } else if (field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                            json += "\"" + new SimpleDateFormat("yyyy-MM-dd").format(getFieldGetter(entity, field).invoke(entity)) + "\"";
                        } else if (field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                            json += ((Date) getFieldGetter(entity, field).invoke(entity)).toInstant();
                        }
                    } else if (field.isAnnotationPresent(ManyToOne.class)) {
                        json += toJSON(getFieldGetter(entity, field).invoke(entity));
                    } else if (field.isAnnotationPresent(OneToMany.class)) {
                        json += "[ \n";
                        List<Object> entityList = (List<Object>) getFieldGetter(entity, field).invoke(entity);
                        for (Object o : entityList) {
                            json += toJSON(o) + ",\n";
                        }
                        json = json.length() > 2 ? json.substring(0, json.length() - 2) : json;
                        json += "\n]";
                    }
                    json += ",\n";
                }
            }
            json = json.length() > 2 ? json.substring(0, json.length() - 2) + "\n}\n" : "{}\n";

        } catch (IOException | IllegalArgumentException | IllegalAccessException | InvocationTargetException | NullPointerException ex) {
            //ex.printStackTrace();
            json = "{}\n";
        }
        return json;
    } //toJSON

    /**
     * JSON to Entity
     *
     * @param <T>
     * @param entityType class type to return
     * @param json String json
     * @return entity of pre-defined type
     */
    public static <T> T fromJSON(Class<T> entityType, String json) {
        Object entity = null;
        if (entityType.isAnnotationPresent(Entity.class) && json.length() > 4) {
            try {
                //Instance object
                entity = entityType.getConstructor().newInstance();
                //prepare json
                json = json.trim().replaceAll("\n", "");
                //exists { } then remove, else isn't json
                if (json.startsWith("{") && json.endsWith("}")) {
                    json = json.substring(1);
                    json = json.substring(0, json.length() - 1);
                } else {
                    entity = null;
                }
                //if is valid json
                if (entity != null) {
                    String[] jsonSplits = json.split(",");
                    //Normalize json splited
                    List<String> jsons = new java.util.ArrayList();
                    for (int i = 0; i < jsonSplits.length; i++) {
                        if (jsonSplits[i].contains("[")) {
                            String jsonPiece = jsonSplits[i] + ",";
                            while (!jsonSplits[i].contains("]")) {
                                i++;
                                jsonPiece += jsonSplits[i] + ",";
                            }
                            jsonPiece = jsonPiece.substring(0, jsonPiece.length() - 1);
                            jsons.add(jsonPiece);
                        } else if (jsonSplits[i].contains("{")) {
                            String jsonPiece = jsonSplits[i] + ",";
                            while (!jsonSplits[i].contains("}")) {
                                i++;
                                jsonPiece += jsonSplits[i] + ",";
                            }
                            jsonPiece = jsonPiece.substring(0, jsonPiece.length() - 1);
                            jsons.add(jsonPiece);
                        } else if (jsonSplits[i].contains("base64")) {
                            jsons.add(jsonSplits[i] + "," + jsonSplits[++i]);
                        } else {
                            jsons.add(jsonSplits[i]);
                        }
                    }

                    //Separate json in tokens
                    for (String jsonTokens : jsons) {
                        //Separate field and value
                        String[] fieldSplit = jsonTokens.split(":");
                        String fieldName = fieldSplit[0].replaceAll("\"", "").trim();
                        if (fieldName.startsWith("{")) {
                            fieldName = fieldName.substring(1);
                        }
                        String jsonValue = "";
                        for (int i = 1; i < fieldSplit.length; i++) {
                            jsonValue += fieldSplit[i].trim() + ":";
                        }
                        jsonValue = jsonValue.substring(0, jsonValue.length() - 1);
                        if (jsonValue.startsWith("\"") && jsonValue.endsWith("\"")) {
                            jsonValue = jsonValue.substring(1);
                            jsonValue = jsonValue.substring(0, jsonValue.length() - 1);
                        }
                        jsonValue = jsonValue.trim();

                        //Get Field and Method
                        Field field = entity.getClass().getDeclaredField(fieldName);
                        Object value = null;
                        Method setter = getFieldSetter(entity, field);

                        //Get value by type var
                        if (setter != null && !jsonValue.isEmpty() && jsonValue.compareTo("null") != 0) {
                            if (field.getType() == Boolean.class) {
                                value = Boolean.parseBoolean(jsonValue);
                            } else if (field.getType() == Byte.class) {
                                value = Byte.parseByte(jsonValue);
                            } else if (field.getType() == Short.class) {
                                value = Short.parseShort(jsonValue);
                            } else if (field.getType() == Integer.class) {
                                value = Integer.parseInt(jsonValue);
                            } else if (field.getType() == Long.class) {
                                value = Long.parseLong(jsonValue);
                            } else if (field.getType() == Float.class) {
                                value = Float.parseFloat(jsonValue);
                            } else if (field.getType() == Double.class) {
                                value = Double.parseDouble(jsonValue);
                            } else if (field.getType() == Character.class) {
                                value = jsonValue.length() > 0 ? jsonValue.charAt(0) : ' ';
                            } else if (field.getType() == String.class) {
                                value = jsonValue;
                            } else if (field.isAnnotationPresent(Enumerated.class)) {
                                value = field.getType().getEnumConstants()[Integer.parseInt(jsonValue)];
                            } else if (field.isAnnotationPresent(Temporal.class) && field.getAnnotation(Temporal.class).value() == TemporalType.TIME) {
                                value = new SimpleDateFormat("hh:mm:ss").parse(jsonValue);
                            } else if (field.isAnnotationPresent(Temporal.class) && field.getAnnotation(Temporal.class).value() == TemporalType.DATE) {
                                value = new SimpleDateFormat("yyyy-MM-dd").parse(jsonValue);
                            } else if (field.isAnnotationPresent(Temporal.class) && field.getAnnotation(Temporal.class).value() == TemporalType.TIMESTAMP) {
                                value = new Date(Long.parseLong(jsonValue));
                            } else if (field.getType() == byte[].class) { //toBase64
                                if (!jsonValue.isEmpty()) {
                                    jsonValue = jsonValue.replaceAll("data:image/png;base64,", "");
                                    value = java.util.Base64.getDecoder().decode(jsonValue);
                                }
                            } else if (field.isAnnotationPresent(ManyToOne.class)) {
                                if (jsonValue.startsWith("{") && jsonValue.endsWith("}")) {
                                    value = fromJSON(field.getType(), jsonValue);
                                } else {
                                    value = null;
                                }
                            } else if (field.isAnnotationPresent(OneToMany.class)) {
                                if (jsonValue.startsWith("[") && jsonValue.endsWith("]")) {
                                    jsonValue = jsonValue.substring(1);
                                    jsonValue = jsonValue.substring(0, jsonValue.length() - 1);
                                    jsonValue = jsonValue.trim();
                                    List<Object> entityList = new java.util.ArrayList<>();
                                    for (String splitValue : jsonValue.split("}")) {
                                        splitValue = splitValue.trim();
                                        if (splitValue.startsWith(",")) {
                                            splitValue = splitValue.substring(1);
                                        }
                                        Class elementType = (Class<?>) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
                                        splitValue = splitValue + (splitValue.startsWith("{") ? "}" : "");
                                        if (!splitValue.isEmpty() && splitValue.compareTo("{}") != 0) {
                                            Object element = fromJSON(elementType, splitValue);
                                            entityList.add(element);
                                        }
                                    }
                                    value = entityList;
                                } else {
                                    value = null;
                                }
                            }
                            //Invoke method if value != null
                            if (value != null) {
                                setter.invoke(entity, value);
                            }
                        }
                    }
                }
            } catch (ParseException | NumberFormatException | NoSuchFieldException | InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException | SecurityException | NullPointerException ex) {
                //ex.printStackTrace();
                entity = null;
            }
        }
        return entityType.cast(entity);
    } //fromJSON

} //EntityManager
