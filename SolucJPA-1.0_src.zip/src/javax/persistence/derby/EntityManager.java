package javax.persistence.derby;

/**
 * Entity Manager Apache Derby
 * @since 2017-05-31
 * @version 1.0
 * @author marcos morise
 */
public abstract class EntityManager extends javax.persistence.EntityManager {

} //EntityManager
