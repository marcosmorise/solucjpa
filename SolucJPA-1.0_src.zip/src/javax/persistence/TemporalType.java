package javax.persistence;

/**
 * @since 2017-05-22
 * @version 1.0
 * @author marcos morise
 */
public enum TemporalType {
    DATE, TIME, TIMESTAMP
}