package javax.persistence.mysql;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

/**
 * Entity Manager MySQL
 * @since 2017-05-31
 * @version 1.0
 * @author marcos morise
 */
public abstract class EntityManager extends javax.persistence.EntityManager {

//*****************************************************************************
// CREATE TABLE Commands ******************************************************
//*****************************************************************************
    /**
     * CreateTable used to create Tables child from entity OneToMany
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param child
     * @throws SQLException
     */
    protected static void createTable(Connection connection, Class owner, Field ownerField, Class child) throws SQLException {
        if (child.isAnnotationPresent(Entity.class)) {
            String sql = createTableSQL(owner, ownerField, child);
            
            //***************************************
            //***************************************
            for (Field field : child.getDeclaredFields()) {
                if (field.isAnnotationPresent(GeneratedValue.class)) {
                    if (field.getType() == Long.class) {
                        sql = sql.replaceAll(
                                " BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH " + field.getAnnotation(GeneratedValue.class).startWith() + ", INCREMENT BY " + field.getAnnotation(GeneratedValue.class).incrementBy() + ")", 
                                " BIGINT NOT NULL AUTO_INCREMENT"
                        );
                    } else {
                        sql = sql.replaceAll(
                                " INT NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH " + field.getAnnotation(GeneratedValue.class).startWith() + ", INCREMENT BY " + field.getAnnotation(GeneratedValue.class).incrementBy() + ")", 
                                " INT NOT NULL AUTO_INCREMENT"
                        );
                    }
                }
            }
            //***************************************
            createTableExecute(connection, owner, ownerField, child, sql);
        }
    } //createTable
    
    /**
     * Create database from entityType
     *
     * @param connection
     * @param entityType
     * @throws SQLException
     */
    public static void createTable(Connection connection, Class entityType) throws SQLException {
        createTable(connection, null, null, entityType);
    } //createTable
    
//*****************************************************************************
// INSERT Commands ************************************************************
//*****************************************************************************

    /**
     * Protected Insert used to insertExecute child from entity OneToMany
     *
     * @param connection
     * @param owner
     * @param ownerField
     * @param entity
     * @throws SQLException
     */
    protected static void insert(Connection connection, Object owner, Field ownerField, Object entity) throws SQLException {
        String tableDefinition = getTableDefinition(entity.getClass());
        String sqlCmd[] = insertSQL(owner, ownerField, entity);
        //***************************************
        sqlCmd[1] = sqlCmd[1].replaceAll(
                "SELECT IDENTITY_VAL_LOCAL() FROM " + tableDefinition, 
                "SELECT LAST_INSERT_ID()"
        );
        //***************************************
        insertExecute(connection, owner, ownerField, entity, sqlCmd);
    } //insert

    /**
     * Insert Entity Into Database
     *
     * @param connection
     * @param entity
     * @throws SQLException
     */
    public static void insert(Connection connection, Object entity) throws SQLException {
        insert(connection, null, null, entity);
    } //insert
    
} //EntityManager
